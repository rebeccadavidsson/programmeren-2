from room import Room

class Adventure():

    # Create rooms and items for the appropriate 'game' version.
    def __init__(self, game):

        # Rooms is a dictionary that maps a room number to the corresponding room object
        self.rooms = {}

        # Parse the rooms from the data file
        data = self.parse_rooms(f"data/{game}Rooms.txt")

        # Create room structures
        self.load_rooms(data)

        # Game always starts in room number 1, so this should be the "current" room
        self.current_room = self.rooms[1]

    # Parse room data line by line
    def parse_rooms(self, filename):

        # List for returning
        rooms_data = []

        # Load from datafile
        with open(filename, "r") as f:
            room_data = []
            for line in f:
                # When there is no blank newline it means there's still data.
                if not line == "\n":
                    room_data.append(line.strip())
                # A blank newline signals all data of a single room is parsed.
                else:
                    rooms_data.append(room_data)
                    room_data = []

        # Append one final time, because the files do not end on a blank newline.
        rooms_data.append(room_data)
        return rooms_data

    # Load rooms from filename in two-step process
    def load_rooms(self, data):

        # Phase 1: Create room objects for each set of data we just parsed.
        for room_data in data:
            # Create identifier
            id = int(room_data[0])

            # Create the object with id, name and description
            new_room = Room(id, room_data[1], room_data[2])
            self.rooms[id] = new_room

        # Phase 2: Link rooms to each other
        for room_data in data:
            # Create identifier
            id = int(room_data[0])

            # Retrieve exisiting room object from dictionary
            room = self.rooms[id]

            # Extract the connection data
            connections = room_data[4:]

            # Add routes to that room (using add_route method)
            for connection in connections:
                direction, target_room_id = connection.split()
                # TODO

    # Pass along the description of the current room
    def get_description(self):
        return self.current_room.description

    # Move to a different room by changing "current" room, if possible
    def move(self, direction):
        # TODO
        pass


if __name__ == "__main__":

    # Create game
    adventure = Adventure("Small")

    # Welcome user
    print("Welcome to Adventure.\n")

    # Print very first room description
    print(adventure.get_description())

    # Prompt the user for commands until they've won the game.
    while True:

        # Prompt
        command = input("> ")

        # Perform move or other command
        # TODO
        pass
